import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import LandingPage from "./pages/landing-page";
import YearlySubscrition from "./pages/yearly-subscrition";
import CreateAccount from "./pages/create-account";
import SignIn from "./pages/sign-in";
import Restaurant from "./pages/restaurant";
import AccomodationListing from "./pages/accomodation-listing";
import AfterPay from "./pages/after-pay";
import MonthlySubscription from "./pages/monthly-subscription";
import Entertainment from "./pages/entertainment";
import OtherServices from "./pages/other-services";
import TourGuides from "./pages/tour-guides";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/yearly-subscrition":
        title = "";
        metaDescription = "";
        break;
      case "/create-account":
        title = "";
        metaDescription = "";
        break;
      case "/sign-in":
        title = "";
        metaDescription = "";
        break;
      case "/restaurant":
        title = "";
        metaDescription = "";
        break;
      case "/accomodation-listing":
        title = "";
        metaDescription = "";
        break;
      case "/after-pay":
        title = "";
        metaDescription = "";
        break;
      case "/monthly-subscription":
        title = "";
        metaDescription = "";
        break;
      case "/entertainment":
        title = "";
        metaDescription = "";
        break;
      case "/other-services":
        title = "";
        metaDescription = "";
        break;
      case "/tour-guides":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/yearly-subscrition" element={<YearlySubscrition />} />
      <Route path="/create-account" element={<CreateAccount />} />
      <Route path="/sign-in" element={<SignIn />} />
      <Route path="/restaurant" element={<Restaurant />} />
      <Route path="/accomodation-listing" element={<AccomodationListing />} />
      <Route path="/after-pay" element={<AfterPay />} />
      <Route path="/monthly-subscription" element={<MonthlySubscription />} />
      <Route path="/entertainment" element={<Entertainment />} />
      <Route path="/other-services" element={<OtherServices />} />
      <Route path="/tour-guides" element={<TourGuides />} />
    </Routes>
  );
}
export default App;
