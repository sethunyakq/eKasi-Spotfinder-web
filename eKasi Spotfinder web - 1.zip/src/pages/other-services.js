import { useCallback } from "react";
import HeaderCardForm from "../components/header-card-form";
import BottomFooter from "../components/bottom-footer";
import styles from "./other-services.module.css";

const OtherServices = () => {
  const onImage103Click = useCallback(() => {
    // Please sync "Location 1" to the project
  }, []);

  return (
    <div className={styles.otherServices}>
      <main className={styles.otherServices1}>
        <HeaderCardForm />
        <section className={styles.serviceTitle}>
          <div className={styles.discoverOtherServicesBethleParent}>
            <h1 className={styles.discoverOtherServices}>
              Discover other services Bethlehem have for you!!!
            </h1>
            <div className={styles.image97Parent}>
              <img
                className={styles.image97Icon}
                alt=""
                src="/image-97@2x.png"
              />
              <img
                className={styles.pin31}
                loading="lazy"
                alt=""
                src="/pin-3-11.svg"
              />
            </div>
          </div>
        </section>
        <div className={styles.socialMediaLogos}>
          <h3 className={styles.hairAndBeauty}>Hair and beauty Salon</h3>
        </div>
        <section className={styles.fRAMEContainer}>
          <div className={styles.image100Parent}>
            <img
              className={styles.image100Icon}
              loading="lazy"
              alt=""
              src="/image-100@2x.png"
            />
            <img
              className={styles.image103Icon}
              loading="lazy"
              alt=""
              src="/image-103@2x.png"
              onClick={onImage103Click}
            />
            <img
              className={styles.image101Icon}
              loading="lazy"
              alt=""
              src="/image-101@2x.png"
            />
            <img
              className={styles.image102Icon}
              loading="lazy"
              alt=""
              src="/image-102@2x.png"
            />
          </div>
        </section>
        <div className={styles.carWashWrapper}>
          <h3 className={styles.carWash}>Car wash</h3>
        </div>
        <section className={styles.fRAMEContainer1}>
          <div className={styles.image105Parent}>
            <img
              className={styles.image105Icon}
              loading="lazy"
              alt=""
              src="/image-105@2x.png"
            />
            <img
              className={styles.image106Icon}
              loading="lazy"
              alt=""
              src="/image-106@2x.png"
            />
            <img
              className={styles.image107Icon}
              loading="lazy"
              alt=""
              src="/image-107@2x.png"
            />
            <img
              className={styles.image109Icon}
              loading="lazy"
              alt=""
              src="/image-109@2x.png"
            />
          </div>
        </section>
        <div className={styles.meterTaxiWrapper}>
          <h3 className={styles.meterTaxi}>Meter taxi</h3>
        </div>
        <section className={styles.fRAMEContainer2}>
          <div className={styles.image110Parent}>
            <img
              className={styles.image110Icon}
              loading="lazy"
              alt=""
              src="/image-110@2x.png"
            />
            <img
              className={styles.image111Icon}
              loading="lazy"
              alt=""
              src="/image-111@2x.png"
            />
            <img
              className={styles.image112Icon}
              loading="lazy"
              alt=""
              src="/image-112@2x.png"
            />
            <img
              className={styles.image114Icon}
              loading="lazy"
              alt=""
              src="/image-114@2x.png"
            />
          </div>
        </section>
        <div className={styles.logosContainer}>
          <h3
            className={styles.healthcareServices}
          >{`Healthcare services `}</h3>
        </div>
        <section className={styles.fRAMEContainer3}>
          <div className={styles.image115Parent}>
            <img
              className={styles.image115Icon}
              loading="lazy"
              alt=""
              src="/image-115@2x.png"
            />
            <img
              className={styles.image116Icon}
              loading="lazy"
              alt=""
              src="/image-116@2x.png"
            />
            <img
              className={styles.image117Icon}
              loading="lazy"
              alt=""
              src="/image-117@2x.png"
            />
            <img
              className={styles.image119Icon}
              loading="lazy"
              alt=""
              src="/image-119@2x.png"
            />
          </div>
        </section>
        <div className={styles.privacyTermsHelp}>
          <div className={styles.logoYoutube4Parent}>
            <img
              className={styles.logoYoutube4}
              loading="lazy"
              alt=""
              src="/logo-youtube-4.svg"
            />
            <img
              className={styles.logoTwitter10}
              loading="lazy"
              alt=""
              src="/logo-twitter-10.svg"
            />
            <img
              className={styles.logoFacebook10}
              loading="lazy"
              alt=""
              src="/logo-facebook-10.svg"
            />
            <img
              className={styles.logoInstagram7}
              loading="lazy"
              alt=""
              src="/logo-instagram-7.svg"
            />
          </div>
        </div>
        <div className={styles.playcineMediaDirectLlcAlWrapper}>
          <div className={styles.playcineMediaDirect}>
            © PlayCine Media Direct, LLC. All rights reserved
          </div>
        </div>
        <BottomFooter />
      </main>
    </div>
  );
};

export default OtherServices;
