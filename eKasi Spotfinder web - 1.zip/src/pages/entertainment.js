import { useCallback } from "react";
import FrameComponent3 from "../components/frame-component3";
import Container3 from "../components/container3";
import styles from "./entertainment.module.css";

const Entertainment = () => {
  const onContainer98Click = useCallback(() => {
    // Please sync "Location 1" to the project
  }, []);

  return (
    <div className={styles.entertainment}>
      <main className={styles.entertainment1}>
        <FrameComponent3 />
        <section className={styles.container97}>
          <div className={styles.textbox38Wrapper}>
            <div className={styles.textbox38}>
              <div className={styles.entertainmentName}>
                <div className={styles.text} />
              </div>
              <h1 className={styles.entertainment2}>ENTERTAINMENT</h1>
            </div>
          </div>
          <div className={styles.suiteContainerParent}>
            <div className={styles.suiteContainer}>
              <Container3
                image59="/image-59@2x.png"
                bostonHarborIslands15Stat="Boston Harbor Islands, 15 State Street, Suite 1100, Boston"
                phone1="/phone-7.svg"
                loveHeartPinIcon="(713) 814-7100"
                loveHeartPin1="/love-heart-pin-11.svg"
                pokebarharborislandsgmail="pokebarharborislands@gmail.com"
                onContainer98Click={onContainer98Click}
              />
              <Container3
                image59="/image-60@2x.png"
                bostonHarborIslands15Stat="827 Boylston St, Boston"
                phone1="/phone-7.svg"
                loveHeartPinIcon="(715) 941-6647"
                loveHeartPin1="/love-heart-pin-11.svg"
                pokebarharborislandsgmail="pokebarboylston@gmail.com"
                propWidth="unset"
                propMinWidth="unset"
                propPadding="0px 0px var(--padding-5xl)"
                propFlex="unset"
                propAlignSelf="unset"
                propGap="50px"
                propAlignSelf1="unset"
                propMinWidth1="111px"
                propWidth1="312px"
                propAlignSelf2="unset"
                propBorder="1px solid var(--color-blueviolet-200)"
                propColor="#6d31ed"
              />
              <Container3
                image59="/image-61@2x.png"
                bostonHarborIslands15Stat="372 Congress St, Boston "
                phone1="/phone-7.svg"
                loveHeartPinIcon="(803) 832-8595"
                loveHeartPin1="/love-heart-pin-11.svg"
                pokebarharborislandsgmail="pokebarcongress@gmail.com"
                propWidth="unset"
                propMinWidth="unset"
                propPadding="0px 0px var(--padding-5xl)"
                propFlex="unset"
                propAlignSelf="unset"
                propGap="50px"
                propAlignSelf1="unset"
                propMinWidth1="117px"
                propWidth1="306px"
                propAlignSelf2="unset"
                propBorder="1px solid var(--color-blueviolet-200)"
                propColor="#6d31ed"
              />
            </div>
            <div className={styles.searchBarWithButtons}>
              <Container3
                image59="/image-62@2x.png"
                bostonHarborIslands15Stat="1 Kendall Square, Boston"
                phone1="/phone-7.svg"
                loveHeartPinIcon="(719) 582-8228"
                loveHeartPin1="/love-heart-pin-11.svg"
                pokebarharborislandsgmail="pokebarkendallsquare@gmail.com"
                propWidth="unset"
                propMinWidth="276px"
                propPadding="0px 0px var(--padding-5xl)"
                propFlex="1"
                propAlignSelf="unset"
                propGap="50px"
                propAlignSelf1="unset"
                propMinWidth1="113px"
                propWidth1="298px"
                propAlignSelf2="unset"
                propBorder="1px solid var(--color-deepskyblue-100)"
                propColor="#15abff"
              />
              <div className={styles.container102Parent}>
                <Container3
                  image59="/image-63@2x.png"
                  bostonHarborIslands15Stat="487 Cambridge St, Allston, Boston"
                  phone1="/phone-7.svg"
                  loveHeartPinIcon="(806) 472-1493"
                  loveHeartPin1="/love-heart-pin-11.svg"
                  pokebarharborislandsgmail="pokebarcambridge@gmail.com"
                  propWidth="unset"
                  propMinWidth="unset"
                  propPadding="0px 0px var(--padding-5xl)"
                  propFlex="unset"
                  propAlignSelf="stretch"
                  propGap="50px"
                  propAlignSelf1="unset"
                  propMinWidth1="114px"
                  propWidth1="unset"
                  propAlignSelf2="stretch"
                  propBorder="1px solid var(--color-deepskyblue-100)"
                  propColor="#15abff"
                />
                <div className={styles.button6Parent}>
                  <div className={styles.button6}>
                    <div className={styles.textWrapper}>
                      <div className={styles.text1} />
                    </div>
                    <img
                      className={styles.chevronLeftLarge}
                      loading="lazy"
                      alt=""
                      src="/chevron-left-large.svg"
                    />
                  </div>
                  <div className={styles.container40}>
                    <b className={styles.b}>1</b>
                  </div>
                  <div className={styles.container39}>
                    <b className={styles.b1}>2</b>
                  </div>
                  <div className={styles.container41}>
                    <b className={styles.b2}>3</b>
                  </div>
                  <div className={styles.container42}>
                    <b className={styles.b3}>4</b>
                  </div>
                  <div className={styles.container43}>
                    <b className={styles.b4}>5</b>
                  </div>
                  <div className={styles.container44}>
                    <b className={styles.b5}>...</b>
                  </div>
                  <div className={styles.container45}>
                    <b className={styles.b6}>30</b>
                  </div>
                  <div className={styles.button7}>
                    <div className={styles.textContainer}>
                      <div className={styles.text2} />
                    </div>
                    <img
                      className={styles.chevronRightLarge}
                      loading="lazy"
                      alt=""
                      src="/chevron-right-large.svg"
                    />
                  </div>
                </div>
              </div>
              <Container3
                image59="/image-64@2x.png"
                bostonHarborIslands15Stat="1 Haviland St, Boston, MA 02115"
                phone1="/phone-7.svg"
                loveHeartPinIcon="(610) 743-8021"
                loveHeartPin1="/love-heart-pin-11.svg"
                pokebarharborislandsgmail="pokebarhaviland@gmail.com"
                propWidth="unset"
                propMinWidth="276px"
                propPadding="0px 0px var(--padding-5xl)"
                propFlex="1"
                propAlignSelf="unset"
                propGap="50px"
                propAlignSelf1="unset"
                propMinWidth1="110px"
                propWidth1="306px"
                propAlignSelf2="unset"
                propBorder="1px solid var(--color-deepskyblue-100)"
                propColor="#15abff"
              />
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Entertainment;
