import { useState, useCallback } from "react";
import FrameComponent1 from "../components/frame-component1";
import { useNavigate } from "react-router-dom";
import StarRatingIcons from "../components/star-rating-icons";
import FrameComponent from "../components/frame-component";
import Container1 from "../components/container1";
import styles from "./accomodation-listing.module.css";

const AccomodationListing = () => {
  const [frameCheckboxChecked, setFrameCheckboxChecked] = useState(true);
  const [frameCheckbox3Checked, setFrameCheckbox3Checked] = useState(true);
  const [frameCheckbox4Checked, setFrameCheckbox4Checked] = useState(true);
  const [frameCheckbox5Checked, setFrameCheckbox5Checked] = useState(true);
  const navigate = useNavigate();

  const onContainer20Click = useCallback(() => {
    navigate("/room-details");
  }, [navigate]);

  return (
    <div className={styles.accomodationListing}>
      <main className={styles.roomListingSearchResults}>
        <FrameComponent1 />
        <section className={styles.roomListingSearchResultsInner}>
          <div className={styles.frameParent}>
            <div className={styles.container24Wrapper}>
              <div className={styles.container24}>
                <div className={styles.container25Parent}>
                  <div className={styles.container25}>
                    <b className={styles.propertyType}>Property type</b>
                    <div className={styles.chevronDownLarge1Wrapper}>
                      <img
                        className={styles.chevronDownLarge1}
                        alt=""
                        src="/chevron-down-large-1.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.frameWrapper}>
                    <div className={styles.frameGroup}>
                      <div className={styles.frameContainer}>
                        <input
                          className={styles.frameInput}
                          checked={frameCheckboxChecked}
                          type="checkbox"
                          onChange={(event) =>
                            setFrameCheckboxChecked(event.target.checked)
                          }
                        />
                      </div>
                      <div className={styles.hotel}>Hotel</div>
                    </div>
                  </div>
                  <div className={styles.frameDiv}>
                    <div className={styles.frameParent1}>
                      <input className={styles.frameInput1} type="checkbox" />
                      <div className={styles.guesthouse}>Guesthouse</div>
                    </div>
                  </div>
                  <div className={styles.frameWrapper1}>
                    <div className={styles.frameParent2}>
                      <input className={styles.frameInput2} type="checkbox" />
                      <div className={styles.house}>House</div>
                    </div>
                  </div>
                  <div className={styles.frameWrapper2}>
                    <div className={styles.frameParent3}>
                      <div className={styles.frameWrapper3}>
                        <input
                          className={styles.frameInput3}
                          checked={frameCheckbox3Checked}
                          type="checkbox"
                          onChange={(event) =>
                            setFrameCheckbox3Checked(event.target.checked)
                          }
                        />
                      </div>
                      <div className={styles.apartment}>Apartment</div>
                    </div>
                  </div>
                </div>
                <div className={styles.container26Parent}>
                  <div className={styles.container26}>
                    <b className={styles.price}>Price</b>
                    <div className={styles.chevronDownLarge2Wrapper}>
                      <img
                        className={styles.chevronDownLarge2}
                        alt=""
                        src="/chevron-down-large-1.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.frameWrapper4}>
                    <div className={styles.frameParent4}>
                      <div className={styles.frameWrapper5}>
                        <input
                          className={styles.frameInput4}
                          checked={frameCheckbox4Checked}
                          type="checkbox"
                          onChange={(event) =>
                            setFrameCheckbox4Checked(event.target.checked)
                          }
                        />
                      </div>
                      <div className={styles.belowR600}>Below R600</div>
                    </div>
                  </div>
                  <div className={styles.frameWrapper6}>
                    <div className={styles.frameParent5}>
                      <div className={styles.frameWrapper7}>
                        <input
                          className={styles.frameInput5}
                          checked={frameCheckbox5Checked}
                          type="checkbox"
                          onChange={(event) =>
                            setFrameCheckbox5Checked(event.target.checked)
                          }
                        />
                      </div>
                      <div className={styles.fromR500To}>
                        From R500 to R1000
                      </div>
                    </div>
                  </div>
                  <div className={styles.frameWrapper8}>
                    <div className={styles.frameParent6}>
                      <input className={styles.frameInput6} type="checkbox" />
                      <div className={styles.fromR800To}>
                        From R800 to R2000
                      </div>
                    </div>
                  </div>
                  <div className={styles.frameWrapper9}>
                    <div className={styles.frameParent7}>
                      <input className={styles.frameInput7} type="checkbox" />
                      <div className={styles.aboveR1500}>Above R1500</div>
                    </div>
                  </div>
                </div>
                <div className={styles.container27}>
                  <b className={styles.reviews}>Reviews</b>
                  <div className={styles.chevronRightLarge1Wrapper}>
                    <img
                      className={styles.chevronRightLarge1}
                      alt=""
                      src="/chevron-right-large-1.svg"
                    />
                  </div>
                </div>
                <div className={styles.container28}>
                  <b className={styles.amenities}>Amenities</b>
                  <div className={styles.chevronRightLarge2Wrapper}>
                    <img
                      className={styles.chevronRightLarge2}
                      alt=""
                      src="/chevron-right-large-1.svg"
                    />
                  </div>
                </div>
                <div className={styles.container30}>
                  <b className={styles.roomsBeds}>{`Rooms & beds`}</b>
                  <div className={styles.chevronRightLarge4Wrapper}>
                    <img
                      className={styles.chevronRightLarge4}
                      alt=""
                      src="/chevron-right-large-1.svg"
                    />
                  </div>
                </div>
                <div className={styles.container29}>
                  <b className={styles.accessibility}>Accessibility</b>
                  <div className={styles.chevronRightLarge3Wrapper}>
                    <img
                      className={styles.chevronRightLarge3}
                      alt=""
                      src="/chevron-right-large-1.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.frameParent8}>
              <div className={styles.staysInBethlehemParent}>
                <div className={styles.staysInBethlehem}>
                  150+ stays in Bethlehem
                </div>
                <div
                  className={styles.container20}
                  onClick={onContainer20Click}
                >
                  <div className={styles.container21}>
                    <div className={styles.reviewImageContainer}>
                      <img
                        className={styles.image26Icon}
                        loading="lazy"
                        alt=""
                        src="/image-26@2x.png"
                      />
                      <div className={styles.guestBedsAmenities} />
                      <div className={styles.reviewImageContainerChild} />
                      <div className={styles.reviewImageContainerItem} />
                      <div className={styles.roomImage} />
                    </div>
                  </div>
                  <StarRatingIcons
                    superiorFamilyRoom="Superior Family Room"
                    guests4Beds1PrivateBath="6 guests • 4 beds • 1 private bath"
                    prop="4.84"
                    reviews="(324 reviews)"
                  />
                  <FrameComponent r1000night="R1000/night" />
                </div>
                <img
                  className={styles.frameChild}
                  loading="lazy"
                  alt=""
                  src="/line-3.svg"
                />
                <div className={styles.container31}>
                  <div className={styles.container32}>
                    <img
                      className={styles.image28Icon}
                      alt=""
                      src="/image-28@2x.png"
                    />
                    <div className={styles.roomImage1}>
                      <div className={styles.roomImage2}>
                        <div className={styles.roomImage3}>
                          <div className={styles.roomImageChild} />
                          <div className={styles.roomImageItem} />
                        </div>
                        <div className={styles.privateBathKitchen} />
                        <div className={styles.privateBathKitchen1} />
                      </div>
                    </div>
                  </div>
                  <StarRatingIcons
                    superiorFamilyRoom="Rainbow Plantation"
                    guests4Beds1PrivateBath="3 guests • 1 bedroom • 1 bath"
                    prop="4.77"
                    reviews="(636 reviews)"
                    starRatingIconsWidth="334px"
                    deluxeLodgingGap="52px"
                    deluxeLodgingWidth="161px"
                    propAlignSelf="stretch"
                    lodgingCategoryAlignSelf="stretch"
                  />
                  <FrameComponent
                    r1000night="R850/night"
                    propPadding="0px var(--padding-11xs)"
                    propMinWidth="83px"
                  />
                </div>
                <img
                  className={styles.frameItem}
                  loading="lazy"
                  alt=""
                  src="/line-3.svg"
                />
                <Container1
                  image29="/image-29@2x.png"
                  juniorSuite="Junior Suite"
                  guests1Bedroom2Beds="3 guests • 1 bedroom • 2 beds"
                  wifiAirConditioning="Wifi • Air conditioning"
                  prop="4.75"
                  reviews="(602 reviews)"
                  r600night="R600/night"
                />
                <img
                  className={styles.frameInner}
                  loading="lazy"
                  alt=""
                  src="/line-3.svg"
                />
                <Container1
                  image29="/image-30@2x.png"
                  juniorSuite="Solitude Pointe"
                  guests1Bedroom2Beds="2 guests • 2 beds • 1 bath"
                  wifiAirConditioning="Kitchen • Wifi • Washer • Air conditioning"
                  prop="4.86"
                  reviews="(42 reviews)"
                  r600night="R1500/night"
                  propPadding="var(--padding-164xl) var(--padding-xl) var(--padding-5xs)"
                  propWidth="325px"
                  propGap="52px"
                  propWidth1="211px"
                  propAlignSelf="stretch"
                  propMinWidth="120px"
                  propDisplay="inline-block"
                  propAlignSelf1="stretch"
                  propMinWidth1="69px"
                  propWidth2="94px"
                  propPadding1="0px var(--padding-8xs)"
                  propMinWidth2="94px"
                  propAlignSelf2="stretch"
                />
                <img
                  className={styles.lineIcon}
                  loading="lazy"
                  alt=""
                  src="/line-3.svg"
                />
                <Container1
                  image29="/image-31@2x.png"
                  juniorSuite="Harley Connection"
                  guests1Bedroom2Beds="4 guests • 2 beds • 1 bath"
                  wifiAirConditioning="Kitchen • Wifi • Washer • Air conditioning"
                  prop="4.84"
                  reviews="(324 reviews)"
                  r600night="R1800/night"
                  propPadding="var(--padding-164xl) var(--padding-xl) var(--padding-5xs) var(--padding-2xl)"
                  propWidth="329px"
                  propGap="52px"
                  propWidth1="211px"
                  propAlignSelf="stretch"
                  propMinWidth="unset"
                  propDisplay="unset"
                  propAlignSelf1="stretch"
                  propMinWidth1="75px"
                  propWidth2="unset"
                  propPadding1="0px var(--padding-9xs)"
                  propMinWidth2="90px"
                  propAlignSelf2="unset"
                />
                <div className={styles.totalStays} />
              </div>
              <div className={styles.frameWrapper10}>
                <div className={styles.button6Parent}>
                  <div className={styles.button6}>
                    <div className={styles.textWrapper}>
                      <div className={styles.text} />
                    </div>
                    <img
                      className={styles.chevronLeftLarge}
                      loading="lazy"
                      alt=""
                      src="/chevron-left-large.svg"
                    />
                  </div>
                  <div className={styles.container40}>
                    <b className={styles.b}>1</b>
                  </div>
                  <div className={styles.container39}>
                    <b className={styles.b1}>2</b>
                  </div>
                  <div className={styles.container41}>
                    <b className={styles.b2}>3</b>
                  </div>
                  <div className={styles.container42}>
                    <b className={styles.b3}>4</b>
                  </div>
                  <div className={styles.container43}>
                    <b className={styles.b4}>5</b>
                  </div>
                  <div className={styles.container44}>
                    <b className={styles.b5}>...</b>
                  </div>
                  <div className={styles.container45}>
                    <b className={styles.b6}>30</b>
                  </div>
                  <div className={styles.button7}>
                    <div className={styles.textContainer}>
                      <div className={styles.text1} />
                    </div>
                    <img
                      className={styles.chevronRightLarge}
                      loading="lazy"
                      alt=""
                      src="/chevron-right-large.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default AccomodationListing;
