import Container6 from "../components/container6";
import Container5 from "../components/container5";
import FrameComponent4 from "../components/frame-component4";
import styles from "./tour-guides.module.css";

const TourGuides = () => {
  return (
    <div className={styles.tourGuides}>
      <main className={styles.tourListing}>
        <header className={styles.container106}>
          <div className={styles.container106Inner}>
            <div className={styles.frameParent}>
              <div className={styles.pin31Wrapper}>
                <img
                  className={styles.pin31}
                  loading="lazy"
                  alt=""
                  src="/pin-3-11.svg"
                />
              </div>
              <i className={styles.ekasiSpotfinder}>
                <span>eKasi Spot</span>
                <span className={styles.finder}>finder</span>
              </i>
            </div>
          </div>
          <div className={styles.container13}>
            <div className={styles.textbox1Wrapper}>
              <div className={styles.textbox1}>
                <div className={styles.find}>FIND:</div>
              </div>
            </div>
            <button className={styles.button3}>
              <div className={styles.searchWrapper}>
                <img className={styles.searchIcon} alt="" src="/search.svg" />
              </div>
              <div className={styles.text} />
            </button>
          </div>
        </header>
        <Container6 />
        <Container5 />
        <section className={styles.container114}>
          <FrameComponent4 />
          <div className={styles.circleSet}>
            <div className={styles.button71Parent}>
              <div className={styles.button71}>
                <div className={styles.iconRow}>
                  <img
                    className={styles.chevronLeftLarge}
                    alt=""
                    src="/chevron-left-large1.svg"
                  />
                </div>
                <div className={styles.text1} />
              </div>
              <div className={styles.button72}>
                <div className={styles.div}>1</div>
              </div>
              <div className={styles.button73}>
                <div className={styles.div1}>2</div>
              </div>
              <div className={styles.button74}>
                <div className={styles.div2}>3</div>
              </div>
              <div className={styles.button75}>
                <div className={styles.div3}>4</div>
              </div>
              <div className={styles.button76}>
                <div className={styles.menu5Wrapper}>
                  <img className={styles.menu5Icon} alt="" src="/menu-5.svg" />
                </div>
                <div className={styles.text2} />
              </div>
              <div className={styles.button77}>
                <div className={styles.div4}>10</div>
              </div>
              <div className={styles.button78}>
                <div className={styles.div5}>11</div>
              </div>
              <div className={styles.button79}>
                <div className={styles.chevronRightLargeWrapper}>
                  <img
                    className={styles.chevronRightLarge}
                    alt=""
                    src="/chevron-right-large1.svg"
                  />
                </div>
                <div className={styles.text3} />
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default TourGuides;
