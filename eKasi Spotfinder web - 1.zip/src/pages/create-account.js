import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../components/button";
import styles from "./create-account.module.css";

const CreateAccount = () => {
  const navigate = useNavigate();

  const onSignInTextClick = useCallback(() => {
    navigate("/sign-in");
  }, [navigate]);

  const onButton141Click = useCallback(() => {
    navigate("/home-destination-listing");
  }, [navigate]);

  return (
    <div className={styles.createAccount}>
      <section className={styles.section}>
        <div className={styles.inner}>
          <div className={styles.facebookAuthBtnParent}>
            <div className={styles.facebookAuthBtn}>
              <div className={styles.frameParent}>
                <div className={styles.pin31Wrapper}>
                  <img
                    className={styles.pin31}
                    loading="lazy"
                    alt=""
                    src="/pin-3-11.svg"
                  />
                </div>
                <div className={styles.ekasiSpotfinderWrapper}>
                  <i className={styles.ekasiSpotfinder}>
                    <span>eKasi Spot</span>
                    <span className={styles.finder}>finder</span>
                  </i>
                </div>
              </div>
              <div className={styles.signUpButtonWrapper}>
                <div className={styles.signUpButton}>
                  <div className={styles.alreadyHaveAn}>
                    Already have an account?
                  </div>
                  <div className={styles.signIn} onClick={onSignInTextClick}>
                    Sign in
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.orLabelWrapper}>
              <div className={styles.orLabel}>
                <div className={styles.createAnAccountWrapper}>
                  <h1 className={styles.createAnAccount}>Create an account</h1>
                </div>
                <div className={styles.orLabelInner}>
                  <div className={styles.textbox64Parent}>
                    <div className={styles.textbox64}>
                      <b className={styles.fullName}>Full name</b>
                      <input
                        className={styles.johnDoe}
                        placeholder="John Doe"
                        type="text"
                      />
                    </div>
                    <div className={styles.textbox63}>
                      <b className={styles.email}>Email</b>
                      <input
                        className={styles.exampleemailgmailcom}
                        placeholder="example.email@gmail.com"
                        type="text"
                      />
                    </div>
                    <div className={styles.textbox62}>
                      <b className={styles.password}>Password</b>
                      <div className={styles.enterAtLeast8CharactersParent}>
                        <div
                          className={styles.enterAtLeast}
                        >{`Enter at least 8+ characters `}</div>
                        <div className={styles.hideWrapper}>
                          <img
                            className={styles.hideIcon}
                            loading="lazy"
                            alt=""
                            src="/hide.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <button className={styles.button141} onClick={onButton141Click}>
                  <div className={styles.signUp}>Sign up</div>
                </button>
                <Button orSignUpWith="Or sign up with" />
              </div>
            </div>
            <div className={styles.bySigningUpYouAgreeWithWrapper}>
              <div className={styles.bySigningUpContainer}>
                <p className={styles.bySigningUp}>
                  By signing up, you agree with the
                </p>
                <p className={styles.termsOfUsePrivacyPolicy}>
                  <span className={styles.termsOfUse}>Terms of Use</span>
                  {` & `}
                  <span className={styles.privacyPolicy}>Privacy Policy</span>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.container170}>
          <img
            className={styles.image133Icon}
            loading="lazy"
            alt=""
            src="/image-133.svg"
          />
          <div className={styles.container170Inner}>
            <div className={styles.welcomeToEkasiSpotfinderParent}>
              <h2 className={styles.welcomeToEkasi}>
                Welcome to Ekasi Spotfinder
              </h2>
              <div className={styles.discoverLocalHotspotsHereWrapper}>
                <div
                  className={styles.discoverLocalHotspots}
                >{`Discover local hotspots here!!! `}</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CreateAccount;
