import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Container from "../components/container";
import styles from "./landing-page.module.css";

const LandingPage = () => {
  const navigate = useNavigate();

  const onButton115Click = useCallback(() => {
    navigate("/create-account");
  }, [navigate]);

  return (
    <div className={styles.landingPage}>
      <main className={styles.screen23}>
        <section className={styles.screen23Inner}>
          <div className={styles.agentsTravelArticlesContainParent}>
            <header className={styles.agentsTravelArticlesContain}>
              <div className={styles.container}>
                <div className={styles.kasiFinderLabelParent}>
                  <div className={styles.kasiFinderLabel}>
                    <img
                      className={styles.vectorIcon}
                      loading="lazy"
                      alt=""
                      src="/vector.svg"
                    />
                  </div>
                  <i className={styles.ekasiSpotfinder}>
                    <span>eKasi Spot</span>
                    <span className={styles.finder}>finder</span>
                  </i>
                </div>
                <div className={styles.pinContainer}>
                  <button
                    className={styles.button115}
                    onClick={onButton115Click}
                  >
                    <div className={styles.signUp}>Sign up</div>
                  </button>
                </div>
              </div>
            </header>
            <div className={styles.frameParent}>
              <div className={styles.welcomeToEkasiSpotfinderdisParent}>
                <div className={styles.welcomeToEkasiContainer}>
                  <p className={styles.welcomeToEkasiSpotfinder}>
                    <span className={styles.welcomeToEkasiSpotfinder1}>
                      <span className={styles.welcomeToEkasi}>
                        Welcome to eKasi Spot
                      </span>
                      <span className={styles.finder1}>finder</span>
                    </span>
                  </p>
                  <p className={styles.discoverLocalHotspotsHere}>
                    <span className={styles.discoverLocalHotspots}>
                      Discover local hotspots here!!!
                    </span>
                    <span className={styles.span}>
                      <span className={styles.span1}>{` `}</span>
                    </span>
                  </p>
                </div>
                <div className={styles.welcometoeKasispotfinder}>
                  <img
                    className={styles.image24Icon}
                    alt=""
                    src="/image-24@2x.png"
                  />
                  <img
                    className={styles.pin32}
                    loading="lazy"
                    alt=""
                    src="/pin-3-1-1.svg"
                  />
                </div>
              </div>
              <div className={styles.rectangleWrapper}>
                <div className={styles.frameChild} />
              </div>
            </div>
          </div>
        </section>
        <div className={styles.pin31} />
        <Container />
      </main>
    </div>
  );
};

export default LandingPage;
