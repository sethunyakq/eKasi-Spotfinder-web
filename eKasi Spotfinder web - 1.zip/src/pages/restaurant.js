import { useCallback } from "react";
import Container3 from "../components/container3";
import styles from "./restaurant.module.css";

const Restaurant = () => {
  const onContainer132Click = useCallback(() => {
    // Please sync "Location 1" to the project
  }, []);

  return (
    <div className={styles.restaurant}>
      <main className={styles.restaurantLocations}>
        <header className={styles.container128}>
          <div className={styles.pinContainer}>
            <div className={styles.frameParent}>
              <div className={styles.pin31Wrapper}>
                <img
                  className={styles.pin31}
                  loading="lazy"
                  alt=""
                  src="/pin-3-11.svg"
                />
              </div>
              <i className={styles.ekasiSpotfinder}>
                <span>eKasi Spot</span>
                <span className={styles.finder}>finder</span>
              </i>
            </div>
          </div>
          <div className={styles.container13}>
            <div className={styles.largeContainer}>
              <div className={styles.textbox1}>
                <div className={styles.find}>FIND:</div>
              </div>
            </div>
            <button className={styles.button3}>
              <div className={styles.searchButton}>
                <img className={styles.searchIcon} alt="" src="/search1.svg" />
              </div>
              <div className={styles.text} />
            </button>
          </div>
        </header>
        <img className={styles.image76Icon} alt="" src="/image-76@2x.png" />
        <section className={styles.container131Wrapper}>
          <div className={styles.container131}>
            <div className={styles.locationsHoursWrapper}>
              <h1 className={styles.locationsHours}>{`Locations & Hours`}</h1>
            </div>
            <div className={styles.container132Parent}>
              <Container3
                image59="/image-78@2x.png"
                bostonHarborIslands15Stat="Boston Harbor Islands, 15 State Street, Suite 1100, Boston"
                phone1="/phone-7.svg"
                loveHeartPinIcon="(713) 814-7100"
                loveHeartPin1="/love-heart-pin-11.svg"
                pokebarharborislandsgmail="pokebarharborislands@gmail.com"
                propWidth="368px"
                propMinWidth="350px"
                propPadding="0px 0px var(--padding-5xl)"
                propFlex="unset"
                propAlignSelf="unset"
                propGap="24px"
                propAlignSelf1="stretch"
                propMinWidth1="106px"
                propWidth1="298px"
                propAlignSelf2="unset"
                propBorder="1px solid var(--color-deepskyblue-100)"
                propColor="#15abff"
                onContainer98Click={onContainer132Click}
              />
              <Container3
                image59="/image-79@2x.png"
                bostonHarborIslands15Stat="827 Boylston St, Boston"
                phone1="/phone-8.svg"
                loveHeartPinIcon="(715) 941-6647"
                loveHeartPin1="/love-heart-pin-12.svg"
                pokebarharborislandsgmail="pokebarboylston@gmail.com"
                propWidth="368px"
                propMinWidth="350px"
                propPadding="0px 0px var(--padding-5xl)"
                propFlex="unset"
                propAlignSelf="unset"
                propGap="50px"
                propAlignSelf1="unset"
                propMinWidth1="111px"
                propWidth1="296px"
                propAlignSelf2="unset"
                propBorder="1px solid var(--color-deepskyblue-100)"
                propColor="#15abff"
              />
              <Container3
                image59="/image-80@2x.png"
                bostonHarborIslands15Stat="372 Congress St, Boston "
                phone1="/phone-8.svg"
                loveHeartPinIcon="(803) 832-8595"
                loveHeartPin1="/love-heart-pin-12.svg"
                pokebarharborislandsgmail="pokebarcongress@gmail.com"
                propWidth="368px"
                propMinWidth="350px"
                propPadding="0px 0px var(--padding-3xl)"
                propFlex="unset"
                propAlignSelf="unset"
                propGap="52px"
                propAlignSelf1="unset"
                propMinWidth1="117px"
                propWidth1="298px"
                propAlignSelf2="unset"
                propBorder="1px solid var(--color-deepskyblue-100)"
                propColor="#15abff"
              />
              <Container3
                image59="/image-81@2x.png"
                bostonHarborIslands15Stat="1 Kendall Square, Boston"
                phone1="/phone-7.svg"
                loveHeartPinIcon="(719) 582-8228"
                loveHeartPin1="/love-heart-pin-11.svg"
                pokebarharborislandsgmail="pokebarkendallsquare@gmail.com"
                propWidth="368px"
                propMinWidth="350px"
                propPadding="0px 0px var(--padding-5xl)"
                propFlex="unset"
                propAlignSelf="unset"
                propGap="50px"
                propAlignSelf1="unset"
                propMinWidth1="113px"
                propWidth1="322px"
                propAlignSelf2="unset"
                propBorder="1px solid var(--color-blueviolet-200)"
                propColor="#6d31ed"
              />
              <Container3
                image59="/image-82@2x.png"
                bostonHarborIslands15Stat="487 Cambridge St, Allston, Boston"
                phone1="/phone-8.svg"
                loveHeartPinIcon="(806) 472-1493"
                loveHeartPin1="/love-heart-pin-12.svg"
                pokebarharborislandsgmail="pokebarcambridge@gmail.com"
                propWidth="368px"
                propMinWidth="350px"
                propPadding="0px 0px var(--padding-5xl)"
                propFlex="unset"
                propAlignSelf="unset"
                propGap="50px"
                propAlignSelf1="unset"
                propMinWidth1="114px"
                propWidth1="unset"
                propAlignSelf2="stretch"
                propBorder="1px solid var(--color-blueviolet-200)"
                propColor="#6d31ed"
              />
              <Container3
                image59="/image-83@2x.png"
                bostonHarborIslands15Stat="1 Haviland St, Boston, MA 02115"
                phone1="/phone-8.svg"
                loveHeartPinIcon="(610) 743-8021"
                loveHeartPin1="/love-heart-pin-12.svg"
                pokebarharborislandsgmail="pokebarhaviland@gmail.com"
                propWidth="368px"
                propMinWidth="350px"
                propPadding="0px 0px var(--padding-5xl)"
                propFlex="unset"
                propAlignSelf="unset"
                propGap="50px"
                propAlignSelf1="unset"
                propMinWidth1="110px"
                propWidth1="unset"
                propAlignSelf2="stretch"
                propBorder="1px solid var(--color-blueviolet-200)"
                propColor="#6d31ed"
              />
            </div>
          </div>
        </section>
        <div className={styles.searchBarWrapper}>
          <div className={styles.button6Parent}>
            <div className={styles.button6}>
              <div className={styles.chevronRightLarge}>
                <div className={styles.text1} />
              </div>
              <img
                className={styles.chevronLeftLarge}
                loading="lazy"
                alt=""
                src="/chevron-left-large.svg"
              />
            </div>
            <div className={styles.container40}>
              <b className={styles.b}>1</b>
            </div>
            <div className={styles.container39}>
              <b className={styles.b1}>2</b>
            </div>
            <div className={styles.container41}>
              <b className={styles.b2}>3</b>
            </div>
            <div className={styles.container42}>
              <b className={styles.b3}>4</b>
            </div>
            <div className={styles.container43}>
              <b className={styles.b4}>5</b>
            </div>
            <div className={styles.container44}>
              <b className={styles.b5}>...</b>
            </div>
            <div className={styles.container45}>
              <b className={styles.b6}>30</b>
            </div>
            <div className={styles.button7}>
              <div className={styles.textWrapper}>
                <div className={styles.text2} />
              </div>
              <img
                className={styles.chevronRightLarge1}
                loading="lazy"
                alt=""
                src="/chevron-right-large.svg"
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Restaurant;
