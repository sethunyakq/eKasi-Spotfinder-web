import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent2 from "../components/frame-component2";
import styles from "./monthly-subscription.module.css";

const MonthlySubscription = () => {
  const navigate = useNavigate();

  const onFrame1Click = useCallback(() => {
    navigate("/yearly-subscription-plan");
  }, [navigate]);

  return (
    <div className={styles.monthlySubscription}>
      <main className={styles.monthlySubscriptionPlan}>
        <div className={styles.ifYouWantToRegisterYourBWrapper}>
          <h1 className={styles.ifYouWant}>
            If you want to register your business on our platform.
          </h1>
        </div>
        <div className={styles.subscriptionPlanWrapper}>
          <h1 className={styles.subscriptionPlan}>Subscription Plan</h1>
        </div>
        <section className={styles.frameParent}>
          <div className={styles.buttonGroup1Wrapper}>
            <div className={styles.buttonGroup1}>
              <button className={styles.frame}>
                <div className={styles.monthly}>Monthly</div>
              </button>
              <button className={styles.frame1} onClick={onFrame1Click}>
                <div className={styles.yearly}>Yearly</div>
              </button>
            </div>
          </div>
          <FrameComponent2 />
        </section>
      </main>
    </div>
  );
};

export default MonthlySubscription;
