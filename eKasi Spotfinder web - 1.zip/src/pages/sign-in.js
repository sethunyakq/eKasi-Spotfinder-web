import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../components/button";
import styles from "./sign-in.module.css";

const SignIn = () => {
  const [frameCheckboxChecked, setFrameCheckboxChecked] = useState(true);
  const navigate = useNavigate();

  const onButton124Click = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  return (
    <div className={styles.signIn}>
      <main className={styles.screen26}>
        <div className={styles.pin31Parent}>
          <img
            className={styles.pin31}
            loading="lazy"
            alt=""
            src="/pin-3-11.svg"
          />
          <i className={styles.ekasiSpotfinder}>
            <span>eKasi Spot</span>
            <span className={styles.finder}>finder</span>
          </i>
        </div>
        <section className={styles.screen26Inner}>
          <div className={styles.frameParent}>
            <div className={styles.welcomeBackWrapper}>
              <h1 className={styles.welcomeBack}>WELCOME BACK</h1>
            </div>
            <div className={styles.oval2Parent}>
              <div className={styles.oval2} />
              <div className={styles.oval21} />
              <div className={styles.container158}>
                <div className={styles.signInLabel}>
                  <div className={styles.frameGroup}>
                    <div className={styles.signInWrapper}>
                      <h1 className={styles.signIn1}>Sign in</h1>
                    </div>
                    <div className={styles.textbox68Parent}>
                      <div className={styles.textbox68}>
                        <b className={styles.email}>Email</b>
                        <input
                          className={styles.exampleemailgmailcom}
                          placeholder="example.email@gmail.com"
                          type="text"
                        />
                      </div>
                      <div className={styles.textbox69}>
                        <b className={styles.password}>Password</b>
                        <div className={styles.enterAtLeast8CharactersParent}>
                          <div
                            className={styles.enterAtLeast}
                          >{`Enter at least 8+ characters `}</div>
                          <div className={styles.rememberMeLabel}>
                            <img
                              className={styles.hideIcon}
                              loading="lazy"
                              alt=""
                              src="/hide.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className={styles.frameContainer}>
                        <div className={styles.frameDiv}>
                          <div className={styles.frameParent1}>
                            <div className={styles.frameWrapper}>
                              <input
                                className={styles.frameInput}
                                checked={frameCheckboxChecked}
                                type="checkbox"
                                onChange={(event) =>
                                  setFrameCheckboxChecked(event.target.checked)
                                }
                              />
                            </div>
                            <div className={styles.rememberMe}>Remember me</div>
                          </div>
                          <div className={styles.forgotPassword}>
                            Forgot password?
                          </div>
                        </div>
                        <button
                          className={styles.button124}
                          onClick={onButton124Click}
                        >
                          <div className={styles.signIn2}>Sign in</div>
                        </button>
                      </div>
                      <Button
                        orSignUpWith="Or sign in with"
                        propPadding="0px var(--padding-xl) 0px var(--padding-2xl)"
                        propWidth="91px"
                        propMinWidth="91px"
                      />
                    </div>
                  </div>
                </div>
                <img
                  className={styles.container159Icon}
                  loading="lazy"
                  alt=""
                  src="/container-159.svg"
                />
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default SignIn;
