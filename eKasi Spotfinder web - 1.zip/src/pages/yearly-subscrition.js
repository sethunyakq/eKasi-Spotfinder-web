import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PaymentButton from "../components/payment-button";
import styles from "./yearly-subscrition.module.css";

const YearlySubscrition = () => {
  const navigate = useNavigate();

  const onMonthlyTextClick = useCallback(() => {
    navigate("/monthly-subscription");
  }, [navigate]);

  return (
    <div className={styles.yearlySubscrition}>
      <main className={styles.yearlySubscriptionPlan}>
        <div className={styles.ifYouWantToRegisterYourBWrapper}>
          <h1 className={styles.ifYouWant}>
            If you want to register your business on our platform.
          </h1>
        </div>
        <div className={styles.subscriptionPlanWrapper}>
          <h1 className={styles.subscriptionPlan}>Subscription Plan</h1>
        </div>
        <section className={styles.frameParent}>
          <div className={styles.buttonGroup1Wrapper}>
            <div className={styles.buttonGroup1}>
              <button className={styles.frame}>
                <div className={styles.monthly} onClick={onMonthlyTextClick}>
                  Monthly
                </div>
              </button>
              <button className={styles.frame1}>
                <div className={styles.yearly}>Yearly</div>
              </button>
            </div>
          </div>
          <PaymentButton />
        </section>
      </main>
    </div>
  );
};

export default YearlySubscrition;
