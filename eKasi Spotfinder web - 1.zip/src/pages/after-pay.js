import { useCallback } from "react";
import NavbarLogoLeft from "../components/navbar-logo-left";
import { useNavigate } from "react-router-dom";
import Footer from "../components/footer";
import styles from "./after-pay.module.css";

const AfterPay = () => {
  const navigate = useNavigate();

  const onButton106Click = useCallback(() => {
    navigate("/home-destination-listing");
  }, [navigate]);

  return (
    <div className={styles.afterPay}>
      <main className={styles.donateSuccessfulPayment}>
        <NavbarLogoLeft />
        <header className={styles.container140}>
          <img
            className={styles.pin31}
            loading="lazy"
            alt=""
            src="/pin-3-11.svg"
          />
          <div className={styles.button104Wrapper}>
            <div className={styles.button104}>
              <div className={styles.needToTalk}>
                Need to talk? (204) 541-9863
              </div>
            </div>
          </div>
        </header>
        <section className={styles.frameParent}>
          <div className={styles.container142Wrapper}>
            <div className={styles.container142}>
              <div className={styles.imageContainer}>
                <img
                  className={styles.image126Icon}
                  loading="lazy"
                  alt=""
                  src="/image-126@2x.png"
                />
              </div>
              <div className={styles.thankYouForRegisteringYourParent}>
                <h1 className={styles.thankYouFor}>
                  Thank you for registering your business with us
                </h1>
                <div className={styles.homepageButtonWrapper}>
                  <div className={styles.homepageButton}>
                    <h3 className={styles.aReceiptHas}>
                      A receipt has been sent to your email
                    </h3>
                    <div className={styles.container143Wrapper}>
                      <div className={styles.container143}>
                        <div className={styles.socialMediaLogosWrapper}>
                          <div className={styles.socialMediaLogos}>
                            <img
                              className={styles.image127Icon}
                              alt=""
                              src="/image-127.svg"
                            />
                            <input
                              className={styles.socialMediaLogosChild}
                              placeholder="We will contact you soon"
                              type="text"
                            />
                          </div>
                        </div>
                        <img
                          className={styles.container143Child}
                          alt=""
                          src="/line-18.svg"
                        />
                      </div>
                    </div>
                    <div className={styles.button106Wrapper}>
                      <button
                        className={styles.button106}
                        onClick={onButton106Click}
                      >
                        <div className={styles.goToHomepage}>
                          Go to homepage
                        </div>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </section>
      </main>
    </div>
  );
};

export default AfterPay;
