import { useMemo } from "react";
import styles from "./container1.module.css";

const Container1 = ({
  image29,
  juniorSuite,
  guests1Bedroom2Beds,
  wifiAirConditioning,
  prop,
  reviews,
  r600night,
  propPadding,
  propWidth,
  propGap,
  propWidth1,
  propAlignSelf,
  propMinWidth,
  propDisplay,
  propAlignSelf1,
  propMinWidth1,
  propWidth2,
  propPadding1,
  propMinWidth2,
  propAlignSelf2,
}) => {
  const container34Style = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const frameDiv1Style = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  const frameDiv2Style = useMemo(() => {
    return {
      gap: propGap,
      width: propWidth1,
    };
  }, [propGap, propWidth1]);

  const frameDiv3Style = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
    };
  }, [propAlignSelf]);

  const juniorSuiteStyle = useMemo(() => {
    return {
      minWidth: propMinWidth,
      display: propDisplay,
    };
  }, [propMinWidth, propDisplay]);

  const frameDiv4Style = useMemo(() => {
    return {
      alignSelf: propAlignSelf1,
    };
  }, [propAlignSelf1]);

  const reviewsStyle = useMemo(() => {
    return {
      minWidth: propMinWidth1,
    };
  }, [propMinWidth1]);

  const frameDiv5Style = useMemo(() => {
    return {
      width: propWidth2,
    };
  }, [propWidth2]);

  const frameDiv6Style = useMemo(() => {
    return {
      padding: propPadding1,
    };
  }, [propPadding1]);

  const r600nightStyle = useMemo(() => {
    return {
      minWidth: propMinWidth2,
      alignSelf: propAlignSelf2,
    };
  }, [propMinWidth2, propAlignSelf2]);

  return (
    <div className={styles.container33}>
      <div className={styles.container34} style={container34Style}>
        <img
          className={styles.image29Icon}
          loading="lazy"
          alt=""
          src={image29}
        />
        <div className={styles.wifiSymbolParent}>
          <div className={styles.wifiSymbol} />
          <div className={styles.wifiSymbol1} />
        </div>
        <div className={styles.guestsAndBedsLabel} />
        <div className={styles.ratingSymbols} />
      </div>
      <div className={styles.container33Inner} style={frameDiv1Style}>
        <div className={styles.frameParent} style={frameDiv2Style}>
          <div className={styles.juniorSuiteParent} style={frameDiv3Style}>
            <b className={styles.juniorSuite} style={juniorSuiteStyle}>
              {juniorSuite}
            </b>
            <div className={styles.vectorParent} style={frameDiv4Style}>
              <img className={styles.frameChild} alt="" src="/line-2.svg" />
              <div className={styles.guests1Container}>
                <p className={styles.guests1}>{guests1Bedroom2Beds}</p>
                <p className={styles.wifiAir}>{wifiAirConditioning}</p>
              </div>
            </div>
          </div>
          <div className={styles.frameGroup}>
            <div className={styles.rating3Wrapper}>
              <img
                className={styles.rating3Icon}
                loading="lazy"
                alt=""
                src="/rating-1.svg"
              />
            </div>
            <b className={styles.b}>{prop}</b>
            <div className={styles.reviews} style={reviewsStyle}>
              {reviews}
            </div>
          </div>
        </div>
      </div>
      <div className={styles.frameContainer} style={frameDiv5Style}>
        <div className={styles.favorite3Wrapper} style={frameDiv6Style}>
          <img
            className={styles.favorite3Icon}
            loading="lazy"
            alt=""
            src="/favorite-1.svg"
          />
        </div>
        <div className={styles.r600night} style={r600nightStyle}>
          {r600night}
        </div>
      </div>
    </div>
  );
};

export default Container1;
