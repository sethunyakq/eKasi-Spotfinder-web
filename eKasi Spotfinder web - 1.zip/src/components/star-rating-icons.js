import { useMemo } from "react";
import styles from "./star-rating-icons.module.css";

const StarRatingIcons = ({
  superiorFamilyRoom,
  guests4Beds1PrivateBath,
  prop,
  reviews,
  starRatingIconsWidth,
  deluxeLodgingGap,
  deluxeLodgingWidth,
  propAlignSelf,
  lodgingCategoryAlignSelf,
}) => {
  const starRatingIconsStyle = useMemo(() => {
    return {
      width: starRatingIconsWidth,
    };
  }, [starRatingIconsWidth]);

  const deluxeLodgingStyle = useMemo(() => {
    return {
      gap: deluxeLodgingGap,
      width: deluxeLodgingWidth,
    };
  }, [deluxeLodgingGap, deluxeLodgingWidth]);

  const roomDetailsContainerStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
    };
  }, [propAlignSelf]);

  const lodgingCategoryStyle = useMemo(() => {
    return {
      alignSelf: lodgingCategoryAlignSelf,
    };
  }, [lodgingCategoryAlignSelf]);

  return (
    <div className={styles.starRatingIcons} style={starRatingIconsStyle}>
      <div className={styles.deluxeLodging} style={deluxeLodgingStyle}>
        <div
          className={styles.roomDetailsContainer}
          style={roomDetailsContainerStyle}
        >
          <b className={styles.superiorFamilyRoom}>{superiorFamilyRoom}</b>
          <div className={styles.lodgingCategory} style={lodgingCategoryStyle}>
            <img
              className={styles.lodgingCategoryChild}
              alt=""
              src="/line-2.svg"
            />
            <div className={styles.guests4Container}>
              <p className={styles.guests4}>{guests4Beds1PrivateBath}</p>
              <p className={styles.kitchenWifi}>
                Kitchen • Wifi • Air conditioning
              </p>
            </div>
          </div>
        </div>
        <div className={styles.likeStarParent}>
          <div className={styles.likeStar}>
            <img
              className={styles.rating1Icon}
              loading="lazy"
              alt=""
              src="/rating-1.svg"
            />
          </div>
          <b className={styles.nightLabels}>{prop}</b>
          <div className={styles.reviews}>{reviews}</div>
        </div>
      </div>
    </div>
  );
};

export default StarRatingIcons;
