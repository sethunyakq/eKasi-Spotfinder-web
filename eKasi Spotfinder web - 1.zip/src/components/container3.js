import { useMemo } from "react";
import styles from "./container3.module.css";

const Container3 = ({
  image59,
  bostonHarborIslands15Stat,
  phone1,
  loveHeartPinIcon,
  loveHeartPin1,
  pokebarharborislandsgmail,
  propWidth,
  propMinWidth,
  propPadding,
  propFlex,
  propAlignSelf,
  propGap,
  propAlignSelf1,
  propMinWidth1,
  propWidth1,
  propAlignSelf2,
  propBorder,
  propColor,
  onContainer98Click,
}) => {
  const container98Style = useMemo(() => {
    return {
      width: propWidth,
      minWidth: propMinWidth,
      padding: propPadding,
      flex: propFlex,
      alignSelf: propAlignSelf,
    };
  }, [propWidth, propMinWidth, propPadding, propFlex, propAlignSelf]);

  const frameDiv7Style = useMemo(() => {
    return {
      gap: propGap,
    };
  }, [propGap]);

  const bostonHarborIslandsStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf1,
    };
  }, [propAlignSelf1]);

  const loveHeartPinStyle = useMemo(() => {
    return {
      minWidth: propMinWidth1,
    };
  }, [propMinWidth1]);

  const frameDiv8Style = useMemo(() => {
    return {
      width: propWidth1,
      alignSelf: propAlignSelf2,
    };
  }, [propWidth1, propAlignSelf2]);

  const button31Style = useMemo(() => {
    return {
      border: propBorder,
    };
  }, [propBorder]);

  const directionStyle = useMemo(() => {
    return {
      color: propColor,
    };
  }, [propColor]);

  return (
    <div
      className={styles.container98}
      onClick={onContainer98Click}
      style={container98Style}
    >
      <img className={styles.image59Icon} loading="lazy" alt="" src={image59} />
      <div className={styles.container98Inner}>
        <div className={styles.bostonHarborBtnsParent} style={frameDiv7Style}>
          <div className={styles.bostonHarborBtns}>
            <b
              className={styles.bostonHarborIslands}
              style={bostonHarborIslandsStyle}
            >
              {bostonHarborIslands15Stat}
            </b>
            <div className={styles.mondaySaturday}>
              Monday - Saturday 10:30 AM - 9:00 PM Sunday - 12:00 PM - 9:00 PM
            </div>
            <div className={styles.directionButton}>
              <div className={styles.kendallSquareContainer}>
                <div className={styles.phone1Wrapper}>
                  <img
                    className={styles.phone1Icon}
                    loading="lazy"
                    alt=""
                    src={phone1}
                  />
                </div>
                <div className={styles.loveHeartPin} style={loveHeartPinStyle}>
                  {loveHeartPinIcon}
                </div>
              </div>
              <div className={styles.emailLinkLabel}>
                <div className={styles.loveHeartPin1Wrapper}>
                  <img
                    className={styles.loveHeartPin1}
                    loading="lazy"
                    alt=""
                    src={loveHeartPin1}
                  />
                </div>
                <div className={styles.pokebarharborislandsgmailcom}>
                  {pokebarharborislandsgmail}
                </div>
              </div>
            </div>
          </div>
          <div className={styles.button31Wrapper} style={frameDiv8Style}>
            <button className={styles.button31} style={button31Style}>
              <div className={styles.direction} style={directionStyle}>
                Direction
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Container3;
