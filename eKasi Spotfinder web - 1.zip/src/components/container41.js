import styles from "./container41.module.css";

const Container4 = ({ image74, maldivesLustAndRomance, rating25 }) => {
  return (
    <div className={styles.container126}>
      <img className={styles.image74Icon} loading="lazy" alt="" src={image74} />
      <div className={styles.container126Inner}>
        <div className={styles.maldivesLustAndRomanceParent}>
          <div className={styles.maldivesLustAnd}>{maldivesLustAndRomance}</div>
          <div className={styles.rating25Parent}>
            <img
              className={styles.rating25Icon}
              loading="lazy"
              alt=""
              src={rating25}
            />
            <div className={styles.favorite16Parent}>
              <img
                className={styles.favorite16Icon}
                alt=""
                src="/favorite-6.svg"
              />
              <img
                className={styles.bookmark11Icon}
                alt=""
                src="/bookmark-1.svg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Container4;
