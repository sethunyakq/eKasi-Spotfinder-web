import { useMemo } from "react";
import styles from "./container4.module.css";

const Container4 = ({
  image63,
  scotlandHighlandClans,
  rating14,
  propWidth,
  propGap,
  propHeight,
  propDisplay,
  onContainer115Click,
}) => {
  const container115Style = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  const frameDiv11Style = useMemo(() => {
    return {
      gap: propGap,
    };
  }, [propGap]);

  const scotlandHighlandClansStyle = useMemo(() => {
    return {
      height: propHeight,
      display: propDisplay,
    };
  }, [propHeight, propDisplay]);

  return (
    <div
      className={styles.container115}
      onClick={onContainer115Click}
      style={container115Style}
    >
      <img className={styles.image63Icon} loading="lazy" alt="" src={image63} />
      <div className={styles.previewMode}>
        <div
          className={styles.scotlandHighlandClansParent}
          style={frameDiv11Style}
        >
          <div
            className={styles.scotlandHighlandClans}
            style={scotlandHighlandClansStyle}
          >
            {scotlandHighlandClans}
          </div>
          <div className={styles.rating14Parent}>
            <img
              className={styles.rating14Icon}
              loading="lazy"
              alt=""
              src={rating14}
            />
            <div className={styles.prototypingPalette}>
              <div className={styles.favorite6Parent}>
                <img
                  className={styles.favorite6Icon}
                  alt=""
                  src="/favorite-6.svg"
                />
                <img
                  className={styles.bookmark1Icon}
                  loading="lazy"
                  alt=""
                  src="/bookmark-1.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Container4;
