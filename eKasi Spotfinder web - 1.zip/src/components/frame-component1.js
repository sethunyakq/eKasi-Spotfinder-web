import styles from "./frame-component1.module.css";

const FrameComponent1 = () => {
  return (
    <section className={styles.container22Parent}>
      <header className={styles.container22}>
        <div className={styles.container22Inner}>
          <div className={styles.pin31Parent}>
            <img
              className={styles.pin31}
              loading="lazy"
              alt=""
              src="/pin-3-11.svg"
            />
            <i className={styles.ekasiSpotfinder}>
              <span>eKasi Spot</span>
              <span className={styles.finder}>finder</span>
            </i>
          </div>
        </div>
        <div className={styles.container13}>
          <div className={styles.textbox1Wrapper}>
            <div className={styles.textbox1}>
              <div className={styles.find}>FIND:</div>
            </div>
          </div>
          <button className={styles.button3}>
            <div className={styles.searchWrapper}>
              <img className={styles.searchIcon} alt="" src="/search.svg" />
            </div>
            <div className={styles.text} />
          </button>
        </div>
      </header>
      <img
        className={styles.image78Icon}
        loading="lazy"
        alt=""
        src="/image-781@2x.png"
      />
    </section>
  );
};

export default FrameComponent1;
