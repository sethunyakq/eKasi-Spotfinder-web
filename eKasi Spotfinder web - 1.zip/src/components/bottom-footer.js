import styles from "./bottom-footer.module.css";

const BottomFooter = () => {
  return (
    <footer className={styles.giftCardsAndNoticesWrapper}>
      <div className={styles.giftCardsAndNotices}>
        <div className={styles.privacyTermsHelpDevices}>
          <div className={styles.privacyParent}>
            <div className={styles.privacy}>Privacy</div>
            <div className={styles.terms}>Terms</div>
            <div className={styles.help}>Help</div>
            <div className={styles.devices}>Devices</div>
          </div>
        </div>
        <div className={styles.helpDevices}>
          <div className={styles.mediaCenter}>Media Center</div>
          <div className={styles.giftCards}>Gift Cards</div>
          <div className={styles.legacyNotices}>Legacy Notices</div>
          <div className={styles.account}>Account</div>
        </div>
      </div>
    </footer>
  );
};

export default BottomFooter;
