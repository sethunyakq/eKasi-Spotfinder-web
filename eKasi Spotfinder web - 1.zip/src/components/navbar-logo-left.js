import styles from "./navbar-logo-left.module.css";

const NavbarLogoLeft = () => {
  return (
    <div className={styles.navbarLogoLeft}>
      <div className={styles.navbarcontainer}>
        <div className={styles.navbarContent}>
          <div className={styles.navbarBrand}>
            <img className={styles.logoIcon} alt="" src="/logo@2x.png" />
          </div>
          <div className={styles.navbarMenu}>
            <div className={styles.navbarLink}>
              <div className={styles.about}>About</div>
            </div>
            <div className={styles.navbarLink1}>
              <div className={styles.features}>Features</div>
            </div>
            <div className={styles.navbarLink2}>
              <div className={styles.pricing}>Pricing</div>
            </div>
            <div className={styles.navbarButton}>
              <div className={styles.getStarted}>GET STARTED</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NavbarLogoLeft;
