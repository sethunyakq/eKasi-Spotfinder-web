import styles from "./frame-component3.module.css";

const FrameComponent3 = () => {
  return (
    <section className={styles.container94Parent}>
      <header className={styles.container94}>
        <div className={styles.eKasiSpotfinderLabel}>
          <div className={styles.findButtonParent}>
            <div className={styles.findButton}>
              <img
                className={styles.pin31}
                loading="lazy"
                alt=""
                src="/pin-3-11.svg"
              />
            </div>
            <div className={styles.bannerContainer}>
              <i className={styles.ekasiSpotfinder}>
                <span>eKasi Spot</span>
                <span className={styles.finder}>finder</span>
              </i>
            </div>
          </div>
        </div>
        <div className={styles.container13}>
          <div className={styles.textbox1Wrapper}>
            <div className={styles.textbox1}>
              <div className={styles.find}>FIND:</div>
            </div>
          </div>
          <button className={styles.button3}>
            <div className={styles.searchWrapper}>
              <img className={styles.searchIcon} alt="" src="/search.svg" />
            </div>
            <div className={styles.text} />
          </button>
        </div>
      </header>
      <img
        className={styles.image57Icon}
        loading="lazy"
        alt=""
        src="/image-57@2x.png"
      />
    </section>
  );
};

export default FrameComponent3;
