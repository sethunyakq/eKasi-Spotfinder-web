import { useMemo } from "react";
import styles from "./frame-component5.module.css";

const FrameComponent5 = ({
  image59,
  days4Nights,
  theBestOfGoldenGateATourO,
  avatar23,
  avatar24,
  outputMerger,
  propWidth,
  frameDivBackgroundImage,
}) => {
  const frameDiv9Style = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  const frameDiv10Style = useMemo(() => {
    return {
      backgroundImage: frameDivBackgroundImage,
    };
  }, [frameDivBackgroundImage]);

  return (
    <div className={styles.container110Wrapper}>
      <div className={styles.container110}>
        <div className={styles.image59Parent} style={frameDiv10Style}>
          <img className={styles.image59Icon} alt="" src={image59} />
          <button className={styles.frame}>
            <div className={styles.timeMachineWrapper}>
              <img
                className={styles.timeMachineIcon}
                alt=""
                src="/time-machine.svg"
              />
            </div>
            <div className={styles.days4Nights}>{days4Nights}</div>
          </button>
        </div>
        <div className={styles.container110Inner}>
          <div className={styles.theBestOfGoldenGateATouParent}>
            <h3 className={styles.theBestOf}>{theBestOfGoldenGateATourO}</h3>
            <div className={styles.frameParent} style={frameDiv9Style}>
              <div className={styles.avatar23Parent}>
                <img
                  className={styles.avatar23Icon}
                  loading="lazy"
                  alt=""
                  src={avatar23}
                />
                <img className={styles.avatar24Icon} alt="" src={avatar24} />
              </div>
              <div className={styles.outputMergerWrapper}>
                <div className={styles.outputMerger}>{outputMerger}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent5;
