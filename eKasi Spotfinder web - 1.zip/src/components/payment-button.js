import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./payment-button.module.css";

const PaymentButton = () => {
  const navigate = useNavigate();

  const onButton44Click = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onButton46Click = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onButton45Click = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  return (
    <div className={styles.paymentButton}>
      <div className={styles.standardContainer}>
        <div className={styles.container84}>
          <h1 className={styles.basic}>Basic</h1>
          <div className={styles.frameParent}>
            <div className={styles.r500Parent}>
              <b className={styles.r500}>R500</b>
              <div className={styles.yearlyWrapper}>
                <div className={styles.yearly}>/yearly</div>
              </div>
            </div>
            <div className={styles.basicFeaturesProductRateParent}>
              <div className={styles.basicFeaturesProductRate}>
                <input
                  className={styles.cCheck1}
                  checked={true}
                  type="radio"
                  name="radioGroup-1"
                />
                <div className={styles.listingWrapper}>
                  <div className={styles.listing}>Listing</div>
                </div>
              </div>
              <div className={styles.buttonPayParent}>
                <div className={styles.buttonPay}>
                  <input
                    className={styles.cCheck2}
                    checked={true}
                    type="radio"
                    name="radioGroup-1"
                  />
                  <input
                    className={styles.cCheck21}
                    checked={true}
                    type="radio"
                    name="radioGroup-1"
                  />
                </div>
                <div className={styles.containerPremiumFeatures}>
                  <div className={styles.basicFeatures}>Basic features</div>
                  <div className={styles.productRate}>Product rate</div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.paymentButton1}>
            <button className={styles.button44} onClick={onButton44Click}>
              <div className={styles.pay}>PAY</div>
            </button>
          </div>
        </div>
      </div>
      <div className={styles.container86}>
        <div className={styles.buttonPayMail}>
          <h1 className={styles.standard}>Standard</h1>
          <div className={styles.frameWrapper}>
            <button className={styles.frame}>
              <div className={styles.popular}>Popular</div>
            </button>
          </div>
        </div>
        <div className={styles.frameGroup}>
          <div className={styles.r1000Parent}>
            <b className={styles.r1000}>R1000</b>
            <div className={styles.yearly1}>/yearly</div>
          </div>
          <div className={styles.frameContainer}>
            <div className={styles.cCheck9Parent}>
              <input
                className={styles.cCheck9}
                checked={true}
                type="radio"
                name="radioGroup-3"
              />
              <div
                className={styles.allBasicFeatures}
              >{`All basic Features `}</div>
            </div>
            <div className={styles.cCheck10Parent}>
              <input
                className={styles.cCheck10}
                checked={true}
                type="radio"
                name="radioGroup-3"
              />
              <div className={styles.customerReviews}>Customer reviews</div>
            </div>
            <div className={styles.cCheck7Parent}>
              <input
                className={styles.cCheck7}
                checked={true}
                type="radio"
                name="radioGroup-3"
              />
              <div className={styles.marketingTool}>Marketing Tool</div>
            </div>
            <div className={styles.cCheck8Parent}>
              <input
                className={styles.cCheck8}
                checked={true}
                type="radio"
                name="radioGroup-3"
              />
              <div className={styles.landingPage}>Landing page</div>
            </div>
          </div>
        </div>
        <button className={styles.button46} onClick={onButton46Click}>
          <div className={styles.pay1}>PAY</div>
        </button>
      </div>
      <div className={styles.paymentButtonFinal}>
        <div className={styles.container85}>
          <div className={styles.premiumcontainer}>
            <h1 className={styles.premium}>Premium</h1>
            <div className={styles.frameFrame}>
              <div className={styles.frame1}>
                <div className={styles.hot}>Hot</div>
              </div>
            </div>
          </div>
          <div className={styles.seobutton}>
            <div className={styles.yearlyParent}>
              <div className={styles.yearly2}>/yearly</div>
              <b className={styles.r1500}>R1500</b>
            </div>
            <div className={styles.frameDiv}>
              <div className={styles.cCheck5Parent}>
                <input
                  className={styles.cCheck5}
                  checked={true}
                  type="radio"
                  name="radioGroup-2"
                />
                <div className={styles.allStandardFeatures}>
                  All Standard Features
                </div>
              </div>
              <div className={styles.cCheck6Parent}>
                <input
                  className={styles.cCheck6}
                  checked={true}
                  type="radio"
                  name="radioGroup-2"
                />
                <div className={styles.seo}>SEO</div>
              </div>
              <div className={styles.cCheck3Parent}>
                <input
                  className={styles.cCheck3}
                  checked={true}
                  type="radio"
                  name="radioGroup-2"
                />
                <div className={styles.dataAnalytics}>Data analytics</div>
              </div>
              <div className={styles.cCheck4Parent}>
                <input
                  className={styles.cCheck4}
                  checked={true}
                  type="radio"
                  name="radioGroup-2"
                />
                <div className={styles.webDesign}>Web Design</div>
              </div>
            </div>
          </div>
          <div className={styles.premiumbutton}>
            <button className={styles.button45} onClick={onButton45Click}>
              <div className={styles.mailWrapper}>
                <img className={styles.mailIcon} alt="" src="/mail.svg" />
              </div>
              <div className={styles.pay2}> PAY</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentButton;
