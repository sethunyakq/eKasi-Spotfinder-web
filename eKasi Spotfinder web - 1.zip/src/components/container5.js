import FrameComponent5 from "./frame-component5";
import styles from "./container5.module.css";

const Container5 = () => {
  return (
    <section className={styles.container108}>
      <div className={styles.container108Inner}>
        <div className={styles.upcomingDeparturesParent}>
          <h1 className={styles.upcomingDepartures}>Upcoming departures</h1>
          <div className={styles.iconButton5Parent}>
            <img
              className={styles.iconButton5}
              loading="lazy"
              alt=""
              src="/icon-button-5.svg"
            />
            <img
              className={styles.iconButton4}
              loading="lazy"
              alt=""
              src="/icon-button-4.svg"
            />
          </div>
        </div>
      </div>
      <div className={styles.frameParent}>
        <div className={styles.container111Wrapper}>
          <div className={styles.container111}>
            <div className={styles.frameGroup}>
              <div className={styles.avatar25Parent}>
                <img
                  className={styles.avatar25Icon}
                  loading="lazy"
                  alt=""
                  src="/avatar-25@2x.png"
                />
                <img
                  className={styles.avatar26Icon}
                  alt=""
                  src="/avatar-26@2x.png"
                />
              </div>
              <div className={styles.wrapper}>
                <div className={styles.div}>+ 831</div>
              </div>
            </div>
            <div className={styles.container111Inner}>
              <div className={styles.image60Parent}>
                <img
                  className={styles.image60Icon}
                  alt=""
                  src="/image-60@2x.png"
                />
                <div className={styles.frame}>
                  <div className={styles.timeMachineWrapper}>
                    <img
                      className={styles.timeMachineIcon}
                      loading="lazy"
                      alt=""
                      src="/time-machine.svg"
                    />
                  </div>
                  <div className={styles.days4Nights}> 5 days 4 nights</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <FrameComponent5
          image59="/image-59@2x.png"
          days4Nights="  5 days 4 nights"
          theBestOfGoldenGateATourO="The Best of Golden gate: A Tour of Free State"
          avatar23="/avatar-23@2x.png"
          avatar24="/avatar-24@2x.png"
          outputMerger="+ 831"
        />
        <div className={styles.container109}>
          <div className={styles.image58Parent}>
            <img className={styles.image58Icon} alt="" src="/image-58@2x.png" />
            <button className={styles.frame1}>
              <div className={styles.timeMachineContainer}>
                <img
                  className={styles.timeMachineIcon1}
                  alt=""
                  src="/time-machine.svg"
                />
              </div>
              <div className={styles.days3Nights}> 4 days 3 nights</div>
            </button>
          </div>
          <div className={styles.container109Inner}>
            <div className={styles.drakensbergAComprehensiveParent}>
              <h2 className={styles.drakensbergA}>
                Drakensberg – A comprehensive travel guide
              </h2>
              <div className={styles.frameContainer}>
                <div className={styles.avatar21Parent}>
                  <img
                    className={styles.avatar21Icon}
                    alt=""
                    src="/avatar-26@2x.png"
                  />
                  <img
                    className={styles.avatar22Icon}
                    loading="lazy"
                    alt=""
                    src="/avatar-25@2x.png"
                  />
                </div>
                <div className={styles.container}>
                  <div className={styles.div1}>+ 2.231</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <FrameComponent5
          image59="/image-61@2x.png"
          days4Nights=" 7 days 6 nights"
          theBestOfGoldenGateATourO="The Great White Maluti mountains: A Tour National Parks"
          avatar23="/avatar-27@2x.png"
          avatar24="/avatar-28@2x.png"
          outputMerger="+ 1.224"
          propWidth="122px"
          frameDivBackgroundImage="url('/image-61@2x.png')"
        />
        <div className={styles.container113Wrapper}>
          <div className={styles.container113}>
            <div className={styles.container113Inner}>
              <div className={styles.image62Parent}>
                <img
                  className={styles.image62Icon}
                  alt=""
                  src="/image-62@2x.png"
                />
                <div className={styles.frame2}>
                  <div className={styles.timeMachineFrame}>
                    <img
                      className={styles.timeMachineIcon2}
                      alt=""
                      src="/time-machine.svg"
                    />
                  </div>
                  <div className={styles.days4Nights1}> 5 days 4 nights</div>
                </div>
              </div>
            </div>
            <div className={styles.frameDiv}>
              <div className={styles.avatar29Parent}>
                <img
                  className={styles.avatar29Icon}
                  loading="lazy"
                  alt=""
                  src="/avatar-29@2x.png"
                />
                <img
                  className={styles.avatar30Icon}
                  alt=""
                  src="/avatar-30@2x.png"
                />
              </div>
              <div className={styles.inputArray}>
                <div className={styles.div2}>+ 784</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Container5;
