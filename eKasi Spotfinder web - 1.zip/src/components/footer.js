import styles from "./footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.container141}>
      <div className={styles.parent}>
        <div className={styles.div}>(204) 541-9863</div>
        <div className={styles.westAvenueSan}>
          2012 West Avenue, San Diego, CA 92122
        </div>
      </div>
      <div className={styles.frameParent}>
        <div className={styles.frameWrapper}>
          <div className={styles.aboutUsParent}>
            <div className={styles.aboutUs}>About us</div>
            <div className={styles.vacancies}>Vacancies</div>
            <div className={styles.faqs}>FAQs</div>
            <div className={styles.contact}>Contact</div>
          </div>
        </div>
        <div className={styles.contactUsLink}>
          <div className={styles.project}>Project</div>
          <div className={styles.howItWorks}>How it works</div>
          <div className={styles.whoWeHelp}>Who we help</div>
          <div className={styles.getInvolved}>Get involved</div>
        </div>
        <div className={styles.frameContainer}>
          <div className={styles.privacyParent}>
            <div className={styles.privacy}>Privacy</div>
            <div className={styles.terms}>Terms</div>
            <div className={styles.sitemap}>Sitemap</div>
            <div className={styles.brandInc}>© 2022 Brand, Inc</div>
          </div>
        </div>
      </div>
      <div className={styles.whoWeHelpGetInvolvedLink}>
        <button className={styles.button105}>
          <div className={styles.helpCenter}>Help Center</div>
        </button>
        <div className={styles.facebookLink}>
          <img
            className={styles.logoTwitter11}
            loading="lazy"
            alt=""
            src="/logo-twitter-11.svg"
          />
          <img
            className={styles.logoFacebook11}
            loading="lazy"
            alt=""
            src="/logo-facebook-11.svg"
          />
          <img
            className={styles.logoLinkedin4}
            loading="lazy"
            alt=""
            src="/logo-linkedin-4.svg"
          />
          <img
            className={styles.logoYoutube5}
            loading="lazy"
            alt=""
            src="/logo-youtube-5.svg"
          />
        </div>
      </div>
    </footer>
  );
};

export default Footer;
