import styles from "./container6.module.css";

const Container6 = () => {
  return (
    <section className={styles.container107}>
      <img className={styles.image57Icon} alt="" src="/image-57@2x.png" />
      <h1 className={styles.expandYourWorld}>Expand Your World</h1>
      <div className={styles.areYouLookingForThePerfecParent}>
        <div className={styles.areYouLooking}>
          Are you looking for the perfect timing for your experience? Gift the
          experience of a lifetime. Access your accommodation world.
        </div>
        <div className={styles.button70Wrapper}>
          <button className={styles.button70}>
            <div
              className={styles.findYourPerfect}
            >{`FIND YOUR PERFECT TRIP `}</div>
            <div className={styles.arrowRightWrapper}>
              <img
                className={styles.arrowRightIcon}
                alt=""
                src="/arrow-right.svg"
              />
            </div>
          </button>
        </div>
      </div>
    </section>
  );
};

export default Container6;
