import { useMemo } from "react";
import styles from "./button.module.css";

const Button = ({ orSignUpWith, propPadding, propWidth, propMinWidth }) => {
  const frameDivStyle = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const orSignUpStyle = useMemo(() => {
    return {
      width: propWidth,
      minWidth: propMinWidth,
    };
  }, [propWidth, propMinWidth]);

  return (
    <div className={styles.button}>
      <div className={styles.frameParent}>
        <div className={styles.orSignUpWithWrapper} style={frameDivStyle}>
          <div className={styles.orSignUp} style={orSignUpStyle}>
            {orSignUpWith}
          </div>
        </div>
        <div className={styles.button144Parent}>
          <button className={styles.button144}>
            <div className={styles.button1}>
              <div className={styles.text} />
            </div>
            <img className={styles.googleIcon} alt="" src="/google.svg" />
          </button>
          <button className={styles.button142}>
            <div className={styles.logoFacebookWrapper}>
              <img
                className={styles.logoFacebookIcon}
                alt=""
                src="/logo-facebook.svg"
              />
            </div>
            <div className={styles.text1} />
          </button>
          <div className={styles.button143}>
            <div className={styles.appleWrapper}>
              <img className={styles.appleIcon} alt="" src="/apple.svg" />
            </div>
            <div className={styles.text2} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Button;
