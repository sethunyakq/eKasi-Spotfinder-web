import { useMemo } from "react";
import styles from "./frame-component.module.css";

const FrameComponent = ({ r1000night, propPadding, propMinWidth }) => {
  const backButtonContainerStyle = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const r1000nightStyle = useMemo(() => {
    return {
      minWidth: propMinWidth,
    };
  }, [propMinWidth]);

  return (
    <div className={styles.staysInBethlehemLabel}>
      <div
        className={styles.backButtonContainer}
        style={backButtonContainerStyle}
      >
        <img
          className={styles.favorite1Icon}
          loading="lazy"
          alt=""
          src="/favorite-1.svg"
        />
      </div>
      <div className={styles.r1000night} style={r1000nightStyle}>
        {r1000night}
      </div>
    </div>
  );
};

export default FrameComponent;
