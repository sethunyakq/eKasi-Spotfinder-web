import { useCallback } from "react";
import Container4 from "./container4";
import styles from "./frame-component4.module.css";

const FrameComponent4 = () => {
  const onContainer115Click = useCallback(() => {
    // Please sync "Location 1" to the project
  }, []);

  return (
    <div className={styles.frameParent}>
      <div className={styles.frameGroup}>
        <div className={styles.departureDateRangeParent}>
          <b className={styles.departureDateRange}>Departure Date Range</b>
          <div className={styles.dropdownButton2}>
            <div className={styles.selectDateRange}>Select Date Range</div>
            <div className={styles.calendarWrapper}>
              <img className={styles.calendarIcon} alt="" src="/calendar.svg" />
            </div>
          </div>
        </div>
        <div className={styles.provincesParent}>
          <b className={styles.provinces}>Provinces</b>
          <div className={styles.masterComponentParent}>
            <input className={styles.masterComponent} type="checkbox" />
            <div className={styles.freeState}>Free State</div>
          </div>
          <div className={styles.frameContainer}>
            <input className={styles.frameInput} type="checkbox" />
            <div className={styles.gauteng}>Gauteng</div>
          </div>
          <div className={styles.frameDiv}>
            <input className={styles.frameInput1} type="checkbox" />
            <div className={styles.kzn}>KZN</div>
          </div>
          <div className={styles.frameParent1}>
            <input className={styles.frameInput2} type="checkbox" />
            <div className={styles.easternCape}>Eastern Cape</div>
          </div>
          <div className={styles.frameParent2}>
            <input className={styles.frameInput3} type="checkbox" />
            <div className={styles.westernCape}> Western Cape</div>
          </div>
          <div className={styles.frameParent3}>
            <input className={styles.frameInput4} type="checkbox" />
            <div className={styles.limpopo}>Limpopo</div>
          </div>
          <div className={styles.frameParent4}>
            <input className={styles.frameInput5} type="checkbox" />
            <div className={styles.mpumalanga}>Mpumalanga</div>
          </div>
          <div className={styles.frameParent5}>
            <input className={styles.frameInput6} type="checkbox" />
            <div className={styles.northWest}>North West</div>
          </div>
        </div>
      </div>
      <div className={styles.frameParent6}>
        <div className={styles.container115Parent}>
          <Container4
            image63="/image-631@2x.png"
            scotlandHighlandClans="Scotland: Highland Clans"
            rating14="/rating-14.svg"
            onContainer115Click={onContainer115Click}
          />
          <div className={styles.container116}>
            <div className={styles.image64Parent}>
              <img
                className={styles.image64Icon}
                loading="lazy"
                alt=""
                src="/image-641@2x.png"
              />
              <div className={styles.propertiesTree}>
                <div className={styles.secretsOfItaly}>Secrets of Italy</div>
              </div>
            </div>
            <div className={styles.container116Inner}>
              <div className={styles.rating15Parent}>
                <img
                  className={styles.rating15Icon}
                  loading="lazy"
                  alt=""
                  src="/rating-15.svg"
                />
                <div className={styles.frameWrapper}>
                  <div className={styles.favorite7Parent}>
                    <img
                      className={styles.favorite7Icon}
                      alt=""
                      src="/favorite-6.svg"
                    />
                    <img
                      className={styles.bookmark2Icon}
                      alt=""
                      src="/bookmark-1.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Container4
            image63="/image-65@2x.png"
            scotlandHighlandClans="Bhutan: Festivals and Temples"
            rating14="/rating-16.svg"
            propWidth="unset"
            propGap="30px"
            propHeight="unset"
            propDisplay="unset"
          />
        </div>
        <div className={styles.shapeCollection}>
          <Container4
            image63="/image-66@2x.png"
            scotlandHighlandClans="Peru: Machu Picchu and the Last Incan Bridges"
            rating14="/rating-15.svg"
            propWidth="275px"
            propGap="2px"
            propHeight="unset"
            propDisplay="unset"
          />
          <Container4
            image63="/image-67@2x.png"
            scotlandHighlandClans={`Ancient Wonders: Egypt & the Nile`}
            rating14="/rating-14.svg"
            propWidth="276px"
            propGap="30px"
            propHeight="unset"
            propDisplay="unset"
          />
          <Container4
            image63="/image-68@2x.png"
            scotlandHighlandClans="Artisans and Exiles: Exploring Japan"
            rating14="/rating-15.svg"
            propWidth="276px"
            propGap="30px"
            propHeight="unset"
            propDisplay="unset"
          />
          <Container4
            image74="/image-74@2x.png"
            maldivesLustAndRomance="Maldives: Lust and Romance"
            rating25="/rating-25.svg"
          />
          <Container4
            image74="/image-70@2x.png"
            maldivesLustAndRomance="New York City: Place of Hustle Culture"
            rating25="/rating-16.svg"
          />
          <Container4
            image74="/image-69@2x.png"
            maldivesLustAndRomance="Kuala Lumpur: Islamic motifs"
            rating25="/rating-15.svg"
          />
        </div>
      </div>
    </div>
  );
};

export default FrameComponent4;
