import styles from "./header-card-form.module.css";

const HeaderCardForm = () => {
  return (
    <header className={styles.container13Wrapper}>
      <div className={styles.container13}>
        <div className={styles.textbox1Wrapper}>
          <div className={styles.textbox1}>
            <div className={styles.find}>FIND:</div>
          </div>
        </div>
        <button className={styles.button3}>
          <div className={styles.searchIcon}>
            <img className={styles.searchIcon1} alt="" src="/search.svg" />
          </div>
          <div className={styles.otherServicesList} />
        </button>
      </div>
    </header>
  );
};

export default HeaderCardForm;
