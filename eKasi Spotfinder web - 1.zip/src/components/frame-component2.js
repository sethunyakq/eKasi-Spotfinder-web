import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./frame-component2.module.css";

const FrameComponent2 = () => {
  const navigate = useNavigate();

  const onButton44Click = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onButton46Click = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onButton45Click = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  return (
    <div className={styles.containerRatingParent}>
      <div className={styles.containerRating}>
        <div className={styles.container84}>
          <div className={styles.basicWrapper}>
            <h1 className={styles.basic}>Basic</h1>
          </div>
          <div className={styles.container84Inner}>
            <div className={styles.productReviewsContainerParent}>
              <div className={styles.productReviewsContainer}>
                <b className={styles.r50}>R50</b>
                <div className={styles.month}>/month</div>
              </div>
              <div className={styles.frameParent}>
                <div className={styles.cCheck1Parent}>
                  <input
                    className={styles.cCheck1}
                    checked={true}
                    type="radio"
                    name="radioGroup-1"
                  />
                  <div className={styles.listingWrapper}>
                    <div className={styles.listing}>Listing</div>
                  </div>
                </div>
                <div className={styles.frameGroup}>
                  <div className={styles.cCheck2Parent}>
                    <input
                      className={styles.cCheck2}
                      checked={true}
                      type="radio"
                      name="radioGroup-1"
                    />
                    <input
                      className={styles.cCheck21}
                      checked={true}
                      type="radio"
                      name="radioGroup-1"
                    />
                  </div>
                  <div className={styles.basicFeaturesParent}>
                    <div className={styles.basicFeatures}>Basic features</div>
                    <div className={styles.productRate}>Product rate</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <button className={styles.button44} onClick={onButton44Click}>
            <div className={styles.pay}>PAY</div>
          </button>
        </div>
      </div>
      <div className={styles.container86}>
        <div className={styles.standardParent}>
          <h1 className={styles.standard}>Standard</h1>
          <div className={styles.frameWrapper}>
            <button className={styles.frame}>
              <div className={styles.popular}>Popular</div>
            </button>
          </div>
        </div>
        <div className={styles.containerReviewsParent}>
          <div className={styles.containerReviews}>
            <div className={styles.r100Wrapper}>
              <b className={styles.r100}>R100</b>
            </div>
            <div className={styles.month1}>month</div>
          </div>
          <div className={styles.frameContainer}>
            <div className={styles.cCheck9Parent}>
              <input
                className={styles.cCheck9}
                checked={true}
                type="radio"
                name="radioGroup-3"
              />
              <div
                className={styles.allBasicFeatures}
              >{`All basic Features `}</div>
            </div>
            <div className={styles.cCheck10Parent}>
              <input
                className={styles.cCheck10}
                checked={true}
                type="radio"
                name="radioGroup-3"
              />
              <div className={styles.customerReviews}>Customer reviews</div>
            </div>
            <div className={styles.cCheck7Parent}>
              <input
                className={styles.cCheck7}
                checked={true}
                type="radio"
                name="radioGroup-3"
              />
              <div className={styles.marketingTool}>Marketing Tool</div>
            </div>
            <div className={styles.cCheck8Parent}>
              <input
                className={styles.cCheck8}
                checked={true}
                type="radio"
                name="radioGroup-3"
              />
              <div className={styles.landingPage}>Landing page</div>
            </div>
          </div>
        </div>
        <button className={styles.button46} onClick={onButton46Click}>
          <div className={styles.pay1}>PAY</div>
        </button>
      </div>
      <div className={styles.containerFinal}>
        <div className={styles.container85}>
          <div className={styles.frameDiv}>
            <div className={styles.premiumParent}>
              <h1 className={styles.premium}>Premium</h1>
              <div className={styles.frameParent1}>
                <div className={styles.frameParent2}>
                  <div className={styles.r150Wrapper}>
                    <b className={styles.r150}>R150</b>
                  </div>
                  <div className={styles.month2}>/month</div>
                </div>
                <div className={styles.frameParent3}>
                  <div className={styles.cCheck5Parent}>
                    <input
                      className={styles.cCheck5}
                      checked={true}
                      type="radio"
                      name="radioGroup-2"
                    />
                    <div className={styles.allStandardFeatures}>
                      All Standard Features
                    </div>
                  </div>
                  <div className={styles.cCheck6Parent}>
                    <input
                      className={styles.cCheck6}
                      checked={true}
                      type="radio"
                      name="radioGroup-2"
                    />
                    <div className={styles.seo}>SEO</div>
                  </div>
                  <div className={styles.cCheck3Parent}>
                    <input
                      className={styles.cCheck3}
                      checked={true}
                      type="radio"
                      name="radioGroup-2"
                    />
                    <div className={styles.dataAnalytics}>Data analytics</div>
                  </div>
                  <div className={styles.cCheck4Parent}>
                    <input
                      className={styles.cCheck4}
                      checked={true}
                      type="radio"
                      name="radioGroup-2"
                    />
                    <div className={styles.webDesign}>Web Design</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.hotButtonWrapper}>
              <div className={styles.hotButton}>
                <div className={styles.hot}>Hot</div>
              </div>
            </div>
          </div>
          <div className={styles.paymentButton}>
            <button className={styles.button45} onClick={onButton45Click}>
              <div className={styles.mailWrapper}>
                <img className={styles.mailIcon} alt="" src="/mail.svg" />
              </div>
              <div className={styles.pay2}> PAY</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent2;
