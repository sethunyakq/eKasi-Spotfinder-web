import styles from "./container.module.css";

const Container = () => {
  return (
    <footer className={styles.container85}>
      <div className={styles.logoutButton}>
        <div className={styles.fAQscustomerservice}>
          <div className={styles.contactUsButtonParent}>
            <div className={styles.contactUsButton}>
              <div className={styles.inputFieldBox}>
                <div className={styles.subscriptionButton}>
                  <div className={styles.privacyAndTermsLink}>
                    <h3 className={styles.support}>Support</h3>
                    <div className={styles.faqs}>FAQ's</div>
                    <div
                      className={styles.customerService}
                    >{`Customer Service `}</div>
                    <div
                      className={styles.safetyResource}
                    >{`Safety Resource `}</div>
                  </div>
                </div>
                <div className={styles.copyrightContainer}>
                  <h3 className={styles.discover}>Discover</h3>
                  <div className={styles.agents}>Agents</div>
                  <div className={styles.travelArticles}>Travel Articles</div>
                  <div className={styles.travellerReview}>Traveller Review</div>
                </div>
              </div>
            </div>
            <div className={styles.container88}>
              <h3 className={styles.about}>About</h3>
              <div className={styles.aboutUs}>About us</div>
              <div className={styles.careers}>Careers</div>
              <div className={styles.howWeWork}>How we work</div>
            </div>
          </div>
          <div className={styles.subscribeButtonLabel}>
            <div className={styles.copyrightInfo}>
              <div className={styles.subscribeToOurNewsletterParent}>
                <h3 className={styles.subscribeToOur}>
                  Subscribe to our newsletter
                </h3>
                <div className={styles.forAnnouncementsAnd}>
                  For announcements and exclusive deals
                </div>
              </div>
              <div className={styles.textbox26Parent}>
                <div className={styles.textbox26}>
                  <div className={styles.envelopeSimpleWrapper}>
                    <img
                      className={styles.envelopeSimpleIcon}
                      alt=""
                      src="/envelope-simple.svg"
                    />
                  </div>
                  <input
                    className={styles.inputYourEmail}
                    placeholder="Input your email"
                    type="text"
                  />
                </div>
                <button className={styles.button23}>
                  <div className={styles.subscribe}>Subscribe</div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.legalinfo}>
        <div className={styles.companyInc}>© 2024 Company, Inc.</div>
        <div className={styles.div}>•</div>
        <div className={styles.privacy}>Privacy</div>
        <div className={styles.div1}>•</div>
        <div className={styles.terms}>Terms</div>
        <div className={styles.vectorParent}>
          <img className={styles.frameChild} alt="" src="/line-37.svg" />
          <img
            className={styles.globe12Icon}
            loading="lazy"
            alt=""
            src="/globe-121.svg"
          />
          <img
            className={styles.logoInstagram6}
            loading="lazy"
            alt=""
            src="/logo-instagram-6.svg"
          />
          <img
            className={styles.logoTwitter6}
            loading="lazy"
            alt=""
            src="/logo-twitter-6.svg"
          />
          <img
            className={styles.logoFacebook6}
            loading="lazy"
            alt=""
            src="/logo-facebook-6.svg"
          />
        </div>
      </div>
      <div className={styles.text}>{`      `}</div>
    </footer>
  );
};

export default Container;
